document.addEventListener('DOMContentLoaded', () => {
    const header = document.querySelector('header');
    
    // Header scroll effect
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Mobile Menu Logic (Simple version for static HTML)
    const createMobileMenu = () => {
        const navContainer = document.querySelector('.nav-container');
        const nav = document.querySelector('nav');
        
        const menuBtn = document.createElement('button');
        menuBtn.innerHTML = '☰';
        menuBtn.className = 'mobile-menu-btn';
        menuBtn.style.cssText = 'display: none; background: none; border: none; color: var(--accent-color); font-size: 1.5rem; cursor: pointer;';
        
        navContainer.insertBefore(menuBtn, nav);

        menuBtn.addEventListener('click', () => {
            nav.classList.toggle('mobile-active');
            menuBtn.innerHTML = nav.classList.contains('mobile-active') ? '✕' : '☰';
        });

        // Add mobile styles dynamically to style.css if needed, 
        // but better to add a style block here for simplicity in this turn
        const style = document.createElement('style');
        style.innerHTML = `
            @media (max-width: 768px) {
                .mobile-menu-btn { display: block !important; }
                nav {
                    display: none;
                    position: absolute;
                    top: 100%;
                    left: 0;
                    width: 100%;
                    background: var(--surface-color);
                    padding: 1rem;
                    border-bottom: 1px solid var(--accent-color);
                }
                nav.mobile-active { display: block !important; }
                .nav-links {
                    flex-direction: column;
                    display: flex !important;
                    gap: 1rem;
                }
            }
        `;
        document.head.appendChild(style);
    };

    createMobileMenu();

    // Fade-in animations on scroll
    const observerOptions = {
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    document.querySelectorAll('.glass-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'var(--transition-smooth)';
        observer.observe(card);
    });
});
